/*
 * mallok.h
 *
 *  Created on: May 12, 2016
 *      Author: Patrick Stevens
 */
 
void create_pool(int size);
void *my_malloc(int size);
void my_free(void *block);

