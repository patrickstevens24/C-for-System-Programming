/*
 * mallok_test.c
 *
 *  Created on: May 12, 2016
 *      Author: Patrick Stevens
 */
 
#include "mallok.h"
#include <stdio.h>
#include <memory.h>
#include <assert.h>

void testOne() {

    int size = 1000;
	  int blockSize = 10;
	  int count = 0;
	  void *ptr;
     
	  create_pool(size);
	  while (NULL != (ptr = my_malloc(blockSize))) {
		   ++count;
    }  
    
    printf("--------------\n");
	  printf("Test One: Pool Size = %d, Block Size = %d, Count = %d\nTest One: Success!\n",
		   size, blockSize, count);
	  printf("--------------\n");
     
}

void testTwo() {

	  int size = 1000;
	  int blockSize = 200;
	  void *ptr[5];
	  int t, n;
     
	  create_pool(size);
     
	  for(n = 0; n < 3; ++n) {
		   for(t = 0; t < 5; ++t) {
			    ptr[t] = my_malloc(blockSize);
          if (ptr[t] == NULL) {
             printf("Test Fail!");
          }
		   }
   
		   for(t = 0; t < 5; ++t){
			    my_free(ptr[t]);
			    ptr[t] = NULL;
		   }
	  }
	  printf("Test Two: Success!\n");
    printf("--------------\n");
}

void testThree() {

    printf("Test Three:\n");
    int size = 1000;
	  void *block1, *block2, *block3, *block4, *block5, *block6, *block7;
	  create_pool(size);
     
	  block1 = my_malloc(200);     
	  block2 = my_malloc(200);     
	  block3 = my_malloc(200);     
	  block4 = my_malloc(200);     
	  block5 = my_malloc(200);

	  my_free(block3);
	  block3 = NULL;

	  block3 = my_malloc(210);
    if (block3 == NULL) {
         printf(" Test Failed: 210 bytes\n");
    } else {
         printf( "Test Success: 210 bytes\n");
    }
     
	  block3 = my_malloc(150);
	  if (block3 == NULL) {
         printf(" Test Failed: 150 bytes\n");
    } else {
         printf(" Test Success: 150 bytes\n");
    }
     
	  block6 = my_malloc(60);
	  if (block6 == NULL) {
         printf(" Test Failed: 60 bytes\n");
    } else {
         printf(" Test Success: 60 bytes\n");
    }
     
	  block7 = my_malloc(50);
    if (block7 == NULL) {
         printf(" Test Failed: 50 bytes\n");
    } else {
         printf(" Test Success: 50 bytes\n");
    }
     
	  printf("Test Three: Success!\n");
    printf("--------------\n");
}

void testFour() {

	  int size = 1000;
	  void *ptr1, *ptr2, *ptr3, *ptr4, *ptr5;
	  char *tmp;
	  create_pool(size);
     
	  ptr1 = my_malloc(200); 
	  memset(ptr1, 'A', 200);
     
	  ptr2 = my_malloc(200);
	  memset(ptr2, 'B', 200);
     
	  ptr3 = my_malloc(200);
	  memset(ptr3, 'C', 200);
     
	  ptr4 = my_malloc(200);
	  memset(ptr4, 'D', 200);
     
	  ptr5 = my_malloc(200);
	  memset(ptr5, 'E', 200);
     
	  for (tmp = (char*)ptr1; tmp < (char*)ptr1 + 200; ++tmp) {
		  assert(*tmp == 'A');
    }
	  for (tmp = (char*)ptr2; tmp < (char*)ptr2 + 200; ++tmp) {
		  assert(*tmp == 'B');
    }
	  for (tmp = (char*)ptr3; tmp < (char*)ptr3 + 200; ++tmp) {
		  assert(*tmp == 'C');
    }
	  for (tmp = (char*)ptr4; tmp < (char*)ptr4 + 200; ++tmp) {
		  assert(*tmp == 'D');
    }
	  for (tmp = (char*)ptr5; tmp < (char*)ptr5 + 200; ++tmp) {
		  assert(*tmp == 'E');
    }
	  printf("Test Four: Success!\n");
    printf("--------------\n");
}

void testFive() {

	  int size = 1000;
	  void *ptr1;
	  void *ptr[10];
	  int t;
     
	  create_pool(size);
	  ptr1 = my_malloc(1000);
	  my_free(ptr1);
     
	  for (t = 0; t < 4; t++) {
		   ptr[t] = my_malloc(250);
	  }
	  for (t = 0; t < 4; t++) {
       my_free(ptr[t]);
	  }
     
	  for (t = 0; t < 10; t++) {
	     ptr[t] = my_malloc(100);  
	  }
    for (t = 0; t < 10; t++) {
       my_free(ptr[t]);
	  }
	  printf("Test Five: Success!\n");
    printf("--------------\n");
}

int main(int argc, char *argv[]) {
	  testOne();
	  testTwo();
	  testThree();
	  testFour();
	  testFive();
	  return 0;
}
