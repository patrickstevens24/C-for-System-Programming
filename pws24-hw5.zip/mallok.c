/*
 * mallok.c
 *
 *  Created on: May 12, 2016
 *      Author: Patrick Stevens
 */

#include "mallok.h"
#include <stdio.h>
#include <stdlib.h>

struct Block;

typedef struct Block {
	  void* add;
	  unsigned bytes;
	  char isFree;
	  struct Block *next;
}Block;

static Block *firstBlock = NULL;

void create_pool(int size) {

   void *memory = malloc(size);

   if (firstBlock) {
		   free(firstBlock->add);
		   free(firstBlock);
		   firstBlock = NULL;
	 }
   
	 if (memory != NULL) {
		   firstBlock = (Block*)malloc(sizeof(Block));
		   firstBlock->next = NULL;
		   firstBlock->isFree = 1;
		   firstBlock->bytes = size;
		   firstBlock->add = memory;
	 }
   
}

void *my_malloc(int size) {

	  Block *temp, *curr, *next;
	  curr = firstBlock;
	  while (curr != NULL && (!curr->isFree || curr->bytes < size)) {
		   curr = curr->next;
	 }
	 if (curr != NULL && curr->isFree && curr->bytes >= size) {
		  if (curr->bytes > size) {
	      temp = (Block*)malloc(sizeof(Block));
			  temp->next = curr->next;
			  temp->isFree = 1;
			  temp->bytes = curr->bytes - size;
			  temp->add = (void*)(size + (char*)curr->add);
			  curr->next = temp;
		  }
      curr->isFree = 0;
		  curr->bytes = size;
		  return curr->add;
	  } else {
		   return NULL;
   }
   
}

void my_free(void *block) {

	  Block *back, *curr, *next;
	  back = NULL;
	  curr = firstBlock;

	  while (curr != NULL && curr->add != block) {
		   back = curr;
		   curr = curr->next;
	  }
  	if (curr == NULL)
  		 return;
  	curr->isFree = 1;
   
  	if (back != NULL && back->isFree) {
  		 back->bytes += curr->bytes;
  		 back->next = curr->next;
  		 free(curr);
  		 curr = back;
  	}
   
  	next = curr->next;
  	if (next != NULL && next->isFree) {
  	   curr->bytes += next->bytes;
  		 curr->next = next->next;
  		 free(next);
  	}
   
}

